/*:
 ## Exercise: 501
 
 You may know the popular darts game called 501. Players start with a score of 501, and have to work down to zero. Here are the rules:
 
 - Each player plays a “round” where they throw three darts at a board.
 - Each throw can score between 1 and 20 points, which may be doubled or tripled depending where it hits on the board.
 - It is also possible to score 25 for the outer bulls-eye or 50 for the inner bulls-eye.
 
 House rule: At the end of three rounds, whoever is closest to zero without going below zero is the winner.
 
 - callout(Exercise): Imagine you’re a game shark. You want to fool people into thinking you’re terrible at this game, but then come back and beat them in one swoop at the end. Model your game progress using variables.\
 \
 Start with a variable set to `501` to hold your overall score.\
 Create another variable set to `0` to hold the score for each round.\
 For each throw, update the value of the round score by adding points from the throw.\
 At the end of each round, calculate your current overall score by subtracting the round score from it. Assign the new value to your overall score, and re-set the round score to zero.\
 \
 How slowly can you “improve” your performance without arousing suspicion? \
 \
 After each round, `print` some statements that your opponents might make. If you can, use the value of your current score in their statements.
 */
var score = 501
var round = 0

round += 9
print("So close yet so far away from the bullseye")
round += 18
print("Try again maybe you''ll be able to score a bullseye")
round += 20
print("Lucky shot")

score = score - round

round = 0

round += 5
print("I keep missing")
round += 20
print("Try again maybe you''ll be able to score a bullseye")
round += 1
print("Unlucky shot")

score = score - round

round = 0

round += 20
print("Nice you didnt miss this time")
round += 20
print("Not bad right?")
round += 15
print("15 isn't that bad")

score = score - round

round = 0

round += 20
print("Nice you didnt miss this time")
round += 12
print("Not bad right?")
round += 16
print("16 is better than 15")

score = score - round

round = 0

round += 20
print("Nice you didnt miss again this time")
round += 20
print("Not bad right?")
round += 20
print("3 lucky shots is what you needed")

score = score - round

round = 0

round += 15
print("Nice you didnt miss it again this time")
round += 12
print("As long as you keep getting double digits you'll be fine")
round += 18
print("A couple more good throws and I'll take the win")

score = score - round

round = 0

round += 0
print("You missed")
round += 20
print("20 after a miss is a good luck sign")
round += 20
print("20 again? must be your lucky day")

score = score - round

round = 0

round += 60
print("Lucky shot")
round += 60
print("Really lucky shot")
round += 60
print("How?????")

score = score - round
/*:
 
 _Copyright © 2017 Apple Inc._
 
 _Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated documentation files (the "Software"), to deal in the Software without restriction, including without limitation the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and to permit persons to whom the Software is furnished to do so, subject to the following conditions:_
 
 _The above copyright notice and this permission notice shall be included in all copies or substantial portions of the Software._
 
 _THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE._
 */
//: [Previous](@previous)  |  page 13 of 13
