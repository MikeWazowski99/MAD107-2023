import UIKit

var greeting = "Hello, Critical Thinking playground"


print("Hello and welcome to a game to decide whether the amount of button presses you make will get you to the next room or to fall into a pit.")

var choice = 1

if choice == 1 {
    print("You pressed the button 5 times which got you into the next room.")
}

else if choice == 2 {
    print("You pressed the button once and fell into the pit.")
}

else if choice == 3 {
    print("You pressed the button 3 times and fell into the pit.")
}


var drink = "coffee"

drink = "water"

print(drink)
